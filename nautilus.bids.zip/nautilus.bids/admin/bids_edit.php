<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/nautilus.bids/bids_edit.php");
?>