<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/nautilus.bids/bids_result_list.php");
?>