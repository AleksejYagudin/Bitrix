<?
IncludeModuleLangFile(__FILE__); // в menu.php точно так же можно использовать языковые файлы

// сформируем верхний пункт меню
$aMenu = array(
    "parent_menu" => "global_menu_services", // поместим в раздел "Сервис"
    "sort"        => 100,                    // вес пункта меню
    "url"         => "",  // ссылка на пункте меню
    "text"        => GetMessage("NAUTILUS_BIDS_MAIN_MENU"),       // текст пункта меню
    "title"       => GetMessage("NAUTILUS_BIDS_MAIN_MENU_TITLE"), // текст всплывающей подсказки
    "icon"        => "form_menu_icon", // малая иконка
    "page_icon"   => "form_page_icon", // большая иконка
    "items_id"    => "menu_webforms",  // идентификатор ветви
    "items"       => array(),          // остальные уровни меню сформируем ниже.
);

$aMenu["items"][] =  array(
    "text" => GetMessage("NAUTILUS_BIDS_RESULT_LIST"),
    "url"  => "bids_result_list.php",
    "icon" => "form_menu_icon",
    "page_icon" => "form_page_icon",
    "title" => GetMessage("NAUTILUS_BIDS_RESULT_LIST_TITLE")
);
return $aMenu;