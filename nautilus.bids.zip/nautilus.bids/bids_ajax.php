<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
use Bitrix\Main\Loader;
Loader::includeModule('nautilus.bids');
use \Nautilus\Bids\helperBids;
use \Nautilus\Bids\BidsTable;
if($_POST['target'] == 'country')
{
    $country = $_POST['countryId'];
    $res = helperBids::getCityName($country);
    echo json_encode($res);
}
if($_POST['target'] == 'categoryDell')
{

   $rsData = BidsTable::getList(array(
        'select' => array('ID'),
        'filter' => array('CATEGORY_ID' => $_POST['categoryId'])
    ));
   $result = $rsData->fetchAll();

   foreach ($result as $arItem)
   {
       BidsTable::delete($arItem);
   }
   helperBids::dellCategory($_POST['categoryId']);
   echo json_encode('ok');
}
if($_POST['target'] == 'brandDell')
{
    if(helperBids::dellBrand($_POST['brandId']))
    {
        echo json_encode('ok');
    }
}
if($_POST['target'] == 'addCategory')
{
    $categorys = helperBids::getCategoryListAll();
    $nextIdCategory = array_pop($categorys);
    $nextId = $nextIdCategory['ID'] + 1;

    $res = Nautilus\Bids\CategoryTable::add(array('NAME' => 'Категория_'.$nextId,'ACTIVE' => 'N', 'POPULAR' => 'N', 'SORT' => 500));
    $result = ['ID' => $res->getId(), 'DATA' => $res->getData()];
    echo json_encode($result);

}
if($_POST['target'] == 'addBrand')
{
    $brands = helperBids::getBrandListAll();
    $nextIdBrand = array_pop($brands);
    $nextId = $nextIdBrand['ID'] + 1;

    $res = Nautilus\Bids\BrandsTable::add(array('NAME' => 'Бренд'.$nextId,'ACTIVE' => 'N', 'POPULAR' => 'N', 'SORT' => 500));
    $result = ['ID' => $res->getId(), 'DATA' => $res->getData()];
    echo json_encode($result);

}


?>
