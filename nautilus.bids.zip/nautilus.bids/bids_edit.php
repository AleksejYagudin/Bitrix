<?php require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php"); // первый общий пролог ?>
<?
use Nautilus\Bids\BidsTable;
use \Nautilus\Bids\helperBids;
use Bitrix\Main\Loader;
use \Bitrix\Main\Type;
Loader::includeModule('nautilus.bids');
?>
<?
$aTabs = array(
    array("DIV" => "edit1", "TAB" => "Закладка1", "ICON"=>"main_user_edit", "TITLE"=>"Закладка2"),
);
$tabControl = new CAdminTabControl("tabControl", $aTabs);

$ID = intval($ID);		// идентификатор редактируемой записи
$message = null;		// сообщение об ошибке
$bVarsFromForm = false; // флаг "Данные получены с формы", обозначающий, что выводимые данные получены с формы, а не из БД.
?>
<?
// ******************************************************************** //
//                ОБРАБОТКА ИЗМЕНЕНИЙ ФОРМЫ                             //
// ******************************************************************** //

if(
    $REQUEST_METHOD == "POST" // проверка метода вызова страницы
    &&
    ($save!="" || $apply!="") // проверка нажатия кнопок "Сохранить" и "Применить"
    &&
    check_bitrix_sessid()     // проверка идентификатора сессии
)
{

    // обработка данных формы
    $arFields = Array(
        "PUBLISH_DATE"   => new Type\Date($_POST['publish_date'], 'd.m.Y'),
        "NAME"           => $_POST['name'],
        "DESCRIPTION"    => $_POST['description'],
        "TYPE_ID"        => $_POST['type-list'],
        "ACTIVE"         => $_POST['active'] == "on"?"Y":"N",
        "CATEGORY_ID"    => $_POST['category-list'],
        "BRAND_ID"       => $_POST['brand-list'],
        "COUNTRY_ID"        => $_POST['country-list'],
        "CITY"           => $_POST['city-list'],
        "PRICE_MIN"      => $_POST['price_min'],
        "PRICE_MAX"      => $_POST['price_max'],
        "USER"           => $_POST['user'],
        "EMAIL"          => $_POST['email'],
        "PHONE"          => $_POST['phone'],
        "STATUS"          => $_POST['status-list'],
    );


    // сохранение данных
    if($ID > 0)
    {
        $res = BidsTable::Update($ID, $arFields);
    }
    else
    {
        $res = BidsTable::Add($arFields);
        $resId = $res->getId();

    }

    if($res->isSuccess())
    {
        if ($apply != "")
        {
            if($resId)
            {
                $ID = $resId;
            }
            LocalRedirect("/bitrix/admin/bids_edit.php?ID=".$ID."&mess=ok&lang=".LANG."&".$tabControl->ActiveTabParam());
        }
        else
        {
            LocalRedirect("/bitrix/admin/bids_result_list.php?lang=".LANG);
        }

    }
    else
    {
        // если в процессе сохранения возникли ошибки - получаем текст ошибки и меняем вышеопределённые переменные
        $errors = $res->getErrorMessages();
        $bVarsFromForm = true;
    }
}
?>

<?
// ******************************************************************** //
//                ВЫБОРКА И ПОДГОТОВКА ДАННЫХ ФОРМЫ                     //
// ******************************************************************** //

$str_ACTIVE = "Y";
$str_NAME = "";
$str_DESCRIPTION = "";
$str_PHONE = "";
$str_EMAIL = "";
$str_USER = "";
$str_PRICE_MIN = "";
$str_PRICE_MAX = "";
$str_STATUS = "";
$str_COUNTRY = "";
$str_CITY = "";
$str_BRAND_ID = "";
$str_CATEGORY_ID = "";
$str_TYPE_ID = "";



if($ID>0)
{
    $bid = BidsTable::GetByID($ID)->fetch();
    $str_ACTIVE = $bid['ACTIVE'];
    $str_PUBLISH_DATE = $bid['PUBLISH_DATE'];
    $str_NAME = $bid['NAME'];
    $str_DESCRIPTION = $bid['DESCRIPTION'];
    $str_TYPE_ID = $bid['TYPE_ID'];
    $str_CATEGORY_ID = $bid['CATEGORY_ID'];
    $str_BRAND_ID = $bid['BRAND_ID'];
    $str_COUNTRY_ID = $bid['COUNTRY_ID'];
    $str_CITY = $bid['CITY'];
    $str_STATUS = $bid['STATUS'];
    $str_PRICE_MIN = $bid['PRICE_MIN'];
    $str_PRICE_MAX = $bid['PRICE_MAX'];
    $str_USER = $bid['USER'];
    $str_EMAIL = $bid['EMAIL'];
    $str_PHONE = $bid['PHONE'];
}

?>
<?
// ******************************************************************** //
//                ВЫВОД ФОРМЫ                                           //
// ******************************************************************** //

// установим заголовок страницы
$APPLICATION->SetTitle(($ID>0? "Редактирование".$ID : "Новая"));?>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php"); // второй общий пролог?>
<?

// конфигурация административного меню
$aMenu = array(
    array(
        "TEXT"=>"Список1",
        "TITLE"=>"Список2",
        "LINK"=>"bids_result_list.php?lang=".LANG,
        "ICON"=>"btn_list",
    )
);

if($ID>0)
{
    $aMenu[] = array("SEPARATOR"=>"Y");
    $aMenu[] = array(
        "TEXT"=>"Добавить1",
        "TITLE"=>"Добавить2",
        "LINK"=>"bids_edit.php?lang=".LANG,
        "ICON"=>"btn_new",
    );
    $aMenu[] = array(
        "TEXT"=>"Удалить1",
        "TITLE"=>"Удалить2",
        "LINK"=>"javascript:if(confirm('"."Хотите удалить?"."'))window.location='bids_result_list.php?ID=".$ID."&action=delete&lang=".LANG."&".bitrix_sessid_get()."';",
        "ICON"=>"btn_delete",
    );
}

// создание экземпляра класса административного меню
$context = new CAdminContextMenu($aMenu);

// вывод административного меню
$context->Show();
?>

<?php
// не забудем разделить подготовку данных и вывод
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

if(!empty($errors))
{
    $errorsStr = implode('<br>',$errors);
    CAdminMessage::ShowMessage($errorsStr);
}

?>

<form method="POST" Action="<?echo $APPLICATION->GetCurPage()?>" ENCTYPE="multipart/form-data" name="post_form">
    <?// проверка идентификатора сессии ?>
    <?echo bitrix_sessid_post();?>
    <input type="hidden" name="lang" value="<?=LANG?>">
    <?if($ID>0 && !$bCopy):?>
        <input type="hidden" name="ID" value="<?=$ID?>">
    <?endif;?>
    <?
    // отобразим заголовки закладок
    $tabControl->Begin();
    ?>
    <?
    //********************
    // первая закладка - форма редактирования параметров рассылки
    //********************
    $tabControl->BeginNextTab();
    ?>
    <tr>
        <td><span class="required">*</span>Активность</td>
        <td><input type="checkbox" name="active" <?if($str_ACTIVE == "Y"):?>checked<?endif?>></td>
    </tr>
    <tr class="adm-detail-required-field">
        <td width="40%">Дата</td>
        <td width="60%"><?echo CalendarDate("publish_date", $str_PUBLISH_DATE, "post_form", "20")?></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Тип заявки</td>
        <td><?=helperBids::getTypeListName($str_TYPE_ID)?></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Имя</td>
        <td><input type="text" name="name" value="<?echo $str_NAME;?>" size="30" maxlength="255"></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Описание</td>
        <td><input type="text" name="description" value="<?echo $str_DESCRIPTION;?>" size="30" maxlength="255"></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Категория</td>
        <td><?=helperBids::getCategoryListName($str_CATEGORY_ID)?></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Бренд</td>
        <td><?=helperBids::getBrandsListName($str_BRAND_ID)?></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Страна</td>
        <td id="select-country"><?=helperBids::getCountryListName($str_COUNTRY_ID)?></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Город</td>
        <?if($str_COUNTRY_ID == '')
        {
            $str_COUNTRY_ID = 1;
        }

            ?>
        <td id="select-city"><?=helperBids::getCityName($str_COUNTRY_ID, $str_CITY)?></td>
    </tr>
    <tr>
        <td>Цена от</td>
        <td><input type="text" name="price_min" value="<?echo $str_PRICE_MIN;?>" size="30" maxlength="255"></td>
    </tr>
    <tr>
        <td>Цена до</td>
        <td><input type="text" name="price_max" value="<?echo $str_PRICE_MAX;?>" size="30" maxlength="255"></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Пользователь</td>
        <td><input type="text" name="user" value="<?echo $str_USER;?>" size="30" maxlength="255"></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Телефон</td>
        <td><input type="text" name="phone" value="<?echo $str_PHONE;?>" size="30" maxlength="255"></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Эл. почта</td>
        <td><input type="text" name="email" value="<?echo $str_EMAIL;?>" size="30" maxlength="255"></td>
    </tr>
    <tr>
        <td><span class="required">*</span>Статус</td>
        <td><?=helperBids::getStatusListName($str_STATUS)?></td>
    </tr>


    <?
    // завершение формы - вывод кнопок сохранения изменений
    $tabControl->Buttons(
        array(

            "back_url"=>"bids_result_list.php?lang=".LANG,
        )
    );
    ?>
    <?
    // завершаем интерфейс закладки
    $tabControl->End();

    ?>


</form>
<script>
    BX.bind(BX('select-country'), 'change', function(e) {
        let selectOptionCountry = e.target.value,
            selectCity = document.querySelector('#select-city');
        BX.ajax({
            url: '/bitrix/admin/bids_ajax.php',
            data: {
                target: 'country',
                countryId: selectOptionCountry
            },
            method: 'POST',
            dataType: 'json',
            onsuccess: function (data) {
                selectCity.innerHTML = '';
                selectCity.insertAdjacentHTML('afterbegin', data);
            },
            onfailure: function () {
                console.error(data);

            }
        });
    });
</script>



<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");?>

