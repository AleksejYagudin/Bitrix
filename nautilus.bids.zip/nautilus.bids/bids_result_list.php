<?
// подключим все необходимые файлы:
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php"); // первый общий пролог
use Bitrix\Main\Loader;

Loader::includeModule('nautilus.bids');
use \Nautilus\Bids\BidsTable;
use \Nautilus\Bids\helperBids;
// подключим языковой файл
IncludeModuleLangFile(__FILE__);

// получим права доступа текущего пользователя на модуль

$sTableID = "bids_table"; // ID таблицы
$oSort = new CAdminSorting($sTableID, "ID", "desc"); // объект сортировки
$lAdmin = new CAdminList($sTableID, $oSort); // основной объект списка


// ******************************************************************** //
//                ОБРАБОТКА ДЕЙСТВИЙ НАД ЭЛЕМЕНТАМИ СПИСКА              //
// ******************************************************************** //

// сохранение отредактированных элементов
if($lAdmin->EditAction())
{

    // пройдем по списку переданных элементов
    foreach($FIELDS as $ID=>$arFields)
    {


        if(!$lAdmin->IsUpdated($ID))
            continue;

        // сохраним изменения каждого элемента
        $DB->StartTransaction();
        $ID = IntVal($ID);
        foreach($arFields as $key=>$value)
            $arData[$key]=$value;


        if(!BidsTable::update($ID,$arData))
        {
            $lAdmin->AddGroupError("Ошибка сохранения"." ", $ID);
            $DB->Rollback();
        }

        $DB->Commit();
    }
}

// обработка одиночных и групповых действий
if(($arID = $lAdmin->GroupAction()))
{
    // если выбрано "Для всех элементов"
    if($_REQUEST['action_target']=='selected')
    {

        $rsData = BidsTable::getList(array(
            'select' => array('ID','PUBLISH_DATE', 'CATEGORY_NAME' => 'CATEGORY.NAME', 'BRAND_NAME' => 'BRAND.NAME', 'NAME', 'COUNTRY_NAME' => 'COUNTRY.NAME', 'CITY', 'STATUS', 'PHONE', 'EMAIL', 'ACTIVE'),

        ));
        while($arRes = $rsData->Fetch())
            $arID[] = $arRes['ID'];
    }

    // пройдем по списку элементов
    foreach($arID as $ID)
    {
        if(strlen($ID)<=0)
            continue;
        $ID = IntVal($ID);

        // для каждого элемента совершим требуемое действие
        switch($_REQUEST['action'])
        {
            // удаление
            case "delete":
                @set_time_limit(0);
                $DB->StartTransaction();
                if(!BidsTable::delete($ID))
                {
                    $DB->Rollback();
                    $lAdmin->AddGroupError("Ошибка удаления", $ID);
                }
                $DB->Commit();
                break;
            case "activate":
            case "deactivate":
                $arFields["ACTIVE"]=($_REQUEST['action']=="activate"?"Y":"N");
                if(!BidsTable::Update($ID, $arFields))
                    $lAdmin->AddGroupError("Ошибка удаления", $ID);
                break;

        }

    }
}

// ******************************************************************** //
//                ВЫБОРКА ЭЛЕМЕНТОВ СПИСКА                              //
// ******************************************************************** //

// опишем элементы фильтра
$FilterArr = Array(
    "find",
    "find_id",
    "find_category"

);

// инициализируем фильтр
$lAdmin->InitFilter($FilterArr);


$q = new \Bitrix\Main\Entity\Query(BidsTable::getEntity());
$q->setSelect(array('ID','PUBLISH_DATE', 'TYPE_NAME' => 'TYPE.NAME', 'CATEGORY_NAME' => 'CATEGORY.NAME', 'BRAND_NAME' => 'BRAND.NAME', 'NAME', 'COUNTRY_NAME' => 'COUNTRY.NAME', 'CITY', 'STATUS', 'PHONE', 'EMAIL', 'ACTIVE'));


if(isset($_GET['find_id']) && $_GET['find_id'] !=null && !isset($_GET['del_filter']))
{
    $q->addFilter('ID',$_GET['find_id'] );
}
if(isset($_GET['find_category']) && $_GET['find_category'] !=null && !isset($_GET['del_filter']))
{
    $q->addFilter('CATEGORY_NAME',$_GET['find_category'] );
}
if(isset($_GET['find_brand']) && $_GET['find_brand'] !=null && !isset($_GET['del_filter']))
{
    $q->addFilter('BRAND_NAME',$_GET['find_brand'] );
}
if(isset($_GET['find_country']) && $_GET['find_country'] !=null && !isset($_GET['del_filter']))
{
    $q->addFilter('COUNTRY_NAME',$_GET['find_country'] );
}
if(isset($_GET['find_city']) && $_GET['find_city'] !=null && !isset($_GET['del_filter']))
{
    $q->addFilter('CITY',$_GET['find_city'] );
}
if(isset($_GET['find_active']) && $_GET['find_active'] !=null && !isset($_GET['del_filter']))
{
    $q->addFilter('ACTIVE',$_GET['find_active'] );
}
if(isset($_GET['find_type']) && $_GET['find_type'] !=null && !isset($_GET['del_filter']))
{
    $q->addFilter('TYPE_ID',$_GET['find_type'] );
}


if(isset($_GET['by']) && $_GET['order'] !=null)
{
    $q->addOrder($_GET['by'], $_GET['order']);
}
if(empty($_GET['by']) && empty($_GET['order']))
{
    $q->addOrder("ID", "ASC");
}



$result = $q->exec();


$rsData = $result->fetchAll();
// преобразуем список в экземпляр класса CAdminResult





$rsData = new CAdminResult($rsData, $sTableID);

// аналогично CDBResult инициализируем постраничную навигацию.
$rsData->NavStart();

// отправим вывод переключателя страниц в основной объект $lAdmin
$lAdmin->NavText($rsData->GetNavPrint("Вывод"));


// ******************************************************************** //
//                ПОДГОТОВКА СПИСКА К ВЫВОДУ                            //
// ******************************************************************** //

$lAdmin->AddHeaders(array(
    array("id"    =>"ID",
        "content"  =>"ID",
        "sort"     =>"ID",
        "default"  =>true,
    ),
    array(  "id"    =>"PUBLISH_DATE",
        "content"  => "Дата",
        "sort"     =>"PUBLISH_DATE",
        "default"  =>true,
    ),
    array("id"    =>"TYPE_NAME",
        "content"  => "Типа заявки",
        "sort"     =>"TYPE_NAME",
        "default"  =>true,
    ),
    array("id"    =>"CATEGORY_NAME",
        "content"  => "Категория",
        "sort"     =>"CATEGORY_NAME",
        "default"  =>true,
    ),
    array("id"    =>"BRAND_NAME",
        "content"  => "Бренд",
        "sort"     =>"BRAND_NAME",
        "default"  =>true,
    ),
    array("id"    =>"NAME",
        "content"  => "ИМЯ",
        "sort"     =>"NAME",
        "default"  =>true,
    ),
    array("id"    =>"STATUS",
        "content"  =>"Состояние",
        "sort"     =>"STATUS",
        "default"  =>true,
    ),
    array("id"    =>"COUNTRY_NAME",
        "content"  =>"Страна",
        "sort"     =>"COUNTRY_NAME",
        "default"  =>true,
    ),
    array(  "id"    =>"CITY",
        "content"  =>"Город",
        "sort"     =>"CITY",
        "default"  =>true,
    ),
    array("id"    =>"PHONE",
        "content"  =>"Телефон",
        "sort"     =>"phone",
        "default"  =>true,
    ),
    array("id"    =>"EMAIL",
        "content"  =>"Эл.почта",
        "sort"     =>"EMAIL",
        "default"  =>true,
    ),
    array("id"    =>"ACTIVE",
        "content"  =>"Публ.",
        "sort"     =>"ACTIVE",
        "default"  =>true,
    ),
));


while($arRes = $rsData->NavNext(true, "f_")):
// создаем строку. результат - экземпляр класса CAdminListRow

    if(helperBids::getActive($arRes))
    {
        $row =& $lAdmin->AddRow($f_ID, $arRes);
    }
    else
    {
        continue;
    }








    // параметр NAME будет редактироваться как текст
    $row->AddInputField("NAME", array("size"=>40));
    $row->AddInputField("EMAIL", array("size"=>20));
    $row->AddInputField("PHONE", array("size"=>20));
    $row->AddCheckField("ACTIVE");



    // сформируем контекстное меню
    $arActions = Array();

    // редактирование элемента
    $arActions[] = array(
        "ICON"=>"edit",
        "DEFAULT"=>true,
        "TEXT"=>"Редактирование",
        "ACTION"=>$lAdmin->ActionRedirect("bids_edit.php?ID=".$f_ID)
    );

    // удаление элемента

    $arActions[] = array(
        "ICON"=>"delete",
        "TEXT"=>"Удаление",
        "ACTION"=>"if(confirm('".GetMessage('rub_del_conf')."')) ".$lAdmin->ActionDoGroup($f_ID, "delete")
    );

    // вставим разделитель
    $arActions[] = array("SEPARATOR"=>true);

    // проверка шаблона для автогенерируемых рассылок
    if (strlen($f_TEMPLATE)>0 && $f_AUTO=="Y")
        $arActions[] = array(
            "ICON"=>"",
            "TEXT"=>GetMessage("rub_check"),
            "ACTION"=>$lAdmin->ActionRedirect("template_test.php?ID=".$f_ID)
        );

    // если последний элемент - разделитель, почистим мусор.
    if(is_set($arActions[count($arActions)-1], "SEPARATOR"))
        unset($arActions[count($arActions)-1]);

    // применим контекстное меню к строке
    $row->AddActions($arActions);
endwhile;

// резюме таблицы
$lAdmin->AddFooter(
    array(
        array("title"=>"Количество элементов", "value"=>$rsData->SelectedRowsCount()), // кол-во элементов
        array("counter"=>true, "title"=>"Выбрано элементов", "value"=>"0"), // счетчик выбранных элементов
    )
);

// групповые действия
$lAdmin->AddGroupActionTable(Array(
    "delete"=>"Удалить выбранные элемены", // удалить выбранные элементы
    "activate"=>"Активировать выбранные элемены", // активировать выбранные элементы
    "deactivate"=>"Деактивировать выбранные элемены", // деактивировать выбранные элементы
));

// ******************************************************************** //
//                АДМИНИСТРАТИВНОЕ МЕНЮ                                 //
// ******************************************************************** //

// сформируем меню из одного пункта - добавление рассылки
$aContext = array(
    array(
        "TEXT"=>"Добавить заявку",
        "LINK"=>"/bitrix/admin/bids_edit.php?lang=".LANG,
        "TITLE"=>"Добавить заявку",
        "ICON"=>"btn_new",
    ),
);

// и прикрепим его к списку
$lAdmin->AddAdminContextMenu($aContext);

// ******************************************************************** //
//                ВЫВОД                                                 //
// ******************************************************************** //

// альтернативный вывод
$lAdmin->CheckListMode();

// установим заголовок страницы
$APPLICATION->SetTitle("222223332");


// не забудем разделить подготовку данных и вывод
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");?>
<?php
// ******************************************************************** //
//                ВЫВОД ФИЛЬТРА                                         //
// ******************************************************************** //
?>
<?php



$oFilter = new CAdminFilter(
    $sTableID."_filter",
    array(
        "ID",
        "Категория",
        "Бренд",
        "Страна",
        "Город"
    )
);

?>
    <form name="find_form" method="get" action="<?echo $APPLICATION->GetCurPage();?>">
        <?$oFilter->Begin();?>

        <tr>
            <td>Публикация:</td>
            <td>
                <?
                $arr = array(
                    "reference" => array(
                        "Да",
                        "Нет",
                    ),
                    "reference_id" => array(
                        "Y",
                        "N",
                    )
                );
                echo SelectBoxFromArray("find_active", $arr, $find_active, "Все", "");
                ?>
            </td>
        </tr>
        <tr>
            <td>Типа заявки:</td>
            <td>
                <?
                $arr = array(
                    "reference" => HelperBids::getTypeName(),
                    "reference_id" =>  HelperBids::getTypeID()
                );
                echo SelectBoxFromArray("find_type", $arr, $find_type, "Все", "");
                ?>
            </td>
        </tr>

        <tr>
            <td><?="ID"?>:</td>
            <td>
                <input type="text" name="find_id" size="47" value="<?echo htmlspecialchars($find_id)?>">
            </td>
        </tr>
        <tr>
            <td><?="Категория"?>:</td>
            <td>
                <input type="text" name="find_category" size="47" value="<?echo htmlspecialchars($find_category)?>">
            </td>
        </tr>
        <tr>
            <td><?="Бренд"?>:</td>
            <td>
                <input type="text" name="find_brand" size="47" value="<?echo htmlspecialchars($find_brand)?>">
            </td>
        </tr>
        <tr>
            <td><?="Страна"?>:</td>
            <td>
                <input type="text" name="find_country" size="47" value="<?echo htmlspecialchars($find_country)?>">
            </td>
        </tr>
        <tr>
            <td><?="Город"?>:</td>
            <td>
                <input type="text" name="find_city" size="47" value="<?echo htmlspecialchars($find_city)?>">
            </td>
        </tr>

        <?
        $oFilter->Buttons(array("table_id"=>$sTableID,"url"=>$APPLICATION->GetCurPage(),"form"=>"find_form"));
        $oFilter->End();
        ?>
    </form>


<?$lAdmin->DisplayList();?>


<?
// завершение страницы
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
?>