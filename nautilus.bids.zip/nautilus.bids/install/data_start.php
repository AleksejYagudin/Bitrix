<?php
use Nautilus\Bids\BidsTable;
use Nautilus\Bids\CategoryTable;
use Nautilus\Bids\TypeTable;
use Nautilus\Bids\BrandsTable;
use Nautilus\Bids\CountryTable;
use Nautilus\Bids\CityTable;
use \Bitrix\Main\Type;
use \Bitrix\Main\Config\Option;


function setBidsType()
{
    TypeTable::add(array('NAME' => 'Продажа','ACTIVE' => 'Y', 'SORT' => 1));
    TypeTable::add(array('NAME' => 'Аренда','ACTIVE' => 'N', 'SORT' => 2));
    TypeTable::add(array('NAME' => 'Запчасти','ACTIVE' => 'N', 'SORT' => 3));
    TypeTable::add(array('NAME' => 'Ремонт и сервис','ACTIVE' => 'N', 'SORT' => 4));
    TypeTable::add(array('NAME' => 'Кредит/Лизинг','ACTIVE' => 'N', 'SORT' => 5));
    TypeTable::add(array('NAME' => 'Перевозка','ACTIVE' => 'N', 'SORT' => 6));
    TypeTable::add(array('NAME' => 'Услуги','ACTIVE' => 'N', 'SORT' => 7));
    TypeTable::add(array('NAME' => 'Другое','ACTIVE' => 'N', 'SORT' => 8));
    TypeTable::add(array('NAME' => 'Прочее','ACTIVE' => 'N', 'SORT' => 9));
};
function setBidsCategory()
{
    CategoryTable::add(array('NAME' => 'Гусеничные экскаваторы','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 1));
    CategoryTable::add(array('NAME' => 'Бульдозеры','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 2));
    CategoryTable::add(array('NAME' => 'Экскаваторы-погрузчики','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 3));
    CategoryTable::add(array('NAME' => 'Колесные экскаваторы','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 4));
    CategoryTable::add(array('NAME' => 'Автокраны','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 5));
    CategoryTable::add(array('NAME' => 'Вилочные погрузчики','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 6));
    CategoryTable::add(array('NAME' => 'Мини-погрузчики','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 7));
    CategoryTable::add(array('NAME' => 'Мини-экскаваторы','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 8));
    CategoryTable::add(array('NAME' => 'Грейдеры (автогрейдеры)','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 9));
    CategoryTable::add(array('NAME' => 'Автобетононасосы','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 10));
    CategoryTable::add(array('NAME' => 'Автобетоносмесители','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 11));
    CategoryTable::add(array('NAME' => 'Автовышки','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 12));
    CategoryTable::add(array('NAME' => 'Автогудронаторы','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 13));
    CategoryTable::add(array('NAME' => 'Автолавки','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 14));
};
function setBidsBrands()
{
    BrandsTable::add(array('NAME' => 'Doosan','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 1));
    BrandsTable::add(array('NAME' => 'Hitachi','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 2));
    BrandsTable::add(array('NAME' => 'JCB','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 3));
    BrandsTable::add(array('NAME' => 'John Deere','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 4));
    BrandsTable::add(array('NAME' => 'Komatsu','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 5));
    BrandsTable::add(array('NAME' => 'Liebherr','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 6));
    BrandsTable::add(array('NAME' => 'Metso','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 7));
    BrandsTable::add(array('NAME' => 'Sany','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 8));
    BrandsTable::add(array('NAME' => 'Terex','ACTIVE' => 'Y', 'POPULAR' => 'Y', 'SORT' => 9));
    BrandsTable::add(array('NAME' => 'Volvo','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 10));
    BrandsTable::add(array('NAME' => 'XCMG','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 11));
    BrandsTable::add(array('NAME' => 'Caterpillar','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 12));
    BrandsTable::add(array('NAME' => 'Bobcat','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 13));
    BrandsTable::add(array('NAME' => 'Амкодор','ACTIVE' => 'Y', 'POPULAR' => 'N', 'SORT' => 14));
};
function setCountryBids()
{
    CountryTable::add(array('NAME' => 'Россия'));
    CountryTable::add(array('NAME' => 'Украина'));
    CountryTable::add(array('NAME' => 'Беларусь'));
    CountryTable::add(array('NAME' => 'Казахстан'));
}
function setOptionBidsList($moduleId)
{
    Option::set($moduleId, "CATEGORY", "Y");
    Option::set($moduleId, "BRAND", "Y");
    Option::set($moduleId, "STATUS", "Y");
    Option::set($moduleId, "EMAIL", "Y");
    Option::set($moduleId, "PHONE", "Y");
}
function setCityBids()
{
    if (\Bitrix\Main\IO\Directory::isDirectoryExists(__DIR__.DIRECTORY_SEPARATOR.'country'))
    {
        $directory=new \Bitrix\Main\IO\Directory(__DIR__.DIRECTORY_SEPARATOR.'country', $siteId = null);
        $files = $directory->getChildren();

        foreach ($files as $arItem)
        {
            if($arItem->getName() == 'russia.txt')
            {
                $country_id = 1;
                setCityBidsDB($arItem, $country_id);
            }
            elseif ($arItem->getName() == 'ukraine.txt')
            {
                $country_id = 2;
                setCityBidsDB($arItem, $country_id);
            }
            elseif (($arItem->getName() == 'belarus.txt'))
            {
                $country_id = 3;
                setCityBidsDB($arItem, $country_id);
            }
            elseif ($arItem->getName() == 'kazakhstan.txt')
            {
                $country_id = 4;
                setCityBidsDB($arItem, $country_id);
            }

        }

    }
}
function setCityBidsDB($file, $country)
{
    $content = file($file->getPath());
    foreach ($content as $arItem)
    {
        CityTable::add(array('COUNTRY_ID' => $country, 'NAME' => trim($arItem)));

    }
}
function setExampleBids()
{
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 1,
        'CATEGORY_ID' => 2,
        'BRAND_ID' => 3,
        'COUNTRY_ID' => '1',
        'CITY' => 'Москва',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'Y'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 1,
        'CATEGORY_ID' => 2,
        'BRAND_ID' => 3,
        'COUNTRY_ID' => '2',
        'CITY' => 'Ананьев',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'N'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 4,
        'CATEGORY_ID' => 5,
        'BRAND_ID' => 6,
        'COUNTRY_ID' => '2',
        'CITY' => 'Курпаты',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'Y'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 4,
        'CATEGORY_ID' => 5,
        'BRAND_ID' => 6,
        'COUNTRY_ID' => '3',
        'CITY' => 'Хотимск',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'Y'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 1,
        'CATEGORY_ID' => 1,
        'BRAND_ID' => 1,
        'COUNTRY_ID' => '1',
        'CITY' => 'Саратов',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'N'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 2,
        'CATEGORY_ID' => 2,
        'BRAND_ID' => 2,
        'COUNTRY_ID' => '3',
        'CITY' => 'Чашники',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'Y'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 3,
        'CATEGORY_ID' => 3,
        'BRAND_ID' => 4,
        'COUNTRY_ID' => '4',
        'CITY' => 'Кзылту',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'N'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 4,
        'CATEGORY_ID' => 4,
        'BRAND_ID' => 4,
        'COUNTRY_ID' => '1',
        'CITY' => 'Курманаевка',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'Y'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 1,
        'CATEGORY_ID' => 2,
        'BRAND_ID' => 3,
        'COUNTRY_ID' => '3',
        'CITY' => 'Могилев',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'Y'
    ));
    BidsTable::add(array(
        'PUBLISH_DATE' => new Type\Date,
        'TYPE_ID' => 1,
        'CATEGORY_ID' => 2,
        'BRAND_ID' => 3,
        'COUNTRY_ID' => '1',
        'CITY' => 'Балаково',
        'STATUS' => 'Новая',
        'PRICE_MIN' => 100,
        'PRICE_MAX' => 200,
        'USER' => 'Сергей Иванов',
        'EMAIL' => 'linvek@mail.ru',
        'PHONE' => '+7(906)305-30-69',
        'NAME' => 'Какое-то название заявки',
        'DESCRIPTION' => 'Длинное описание заявки длинное описание заявки длинное описание заявки длинное описание заявки',
        'ACTIVE' => 'N'
    ));
}