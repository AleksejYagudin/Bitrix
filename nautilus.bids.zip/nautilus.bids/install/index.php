<?php
use \Bitrix\Main\Localization\Loc;
use \Bitrix\Main\Config\Option;
use \Bitrix\Main\Loader;
use \Bitrix\Main\Entity\Base;
use \Bitrix\Main\Application;
require_once ('data_start.php');


Loc::loadMessages(__FILE__);

class nautilus_bids extends CModule
{
    var $exclusionAdminFiles;
    function __construct()
    {
        $arModuleVersion = array();
        include(__DIR__."/version.php");

        $this->exclusionAdminFiles=array(
            '..',
            '.',
            'menu.php'
        );


        $this->MODULE_ID = 'nautilus.bids';
        $this->MODULE_VERSION = $arModuleVersion["VERSION"];
        $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
        $this->MODULE_NAME = Loc::getMessage("NAUTILUS_BIDS_MODULE_NAME");
        $this->MODULE_DESCRIPTION = Loc::getMessage("NAUTILUS_BIDS_MODULE_DESC");

        $this->PARTNER_NAME = Loc::getMessage("NAUTILUS_BIDS_PARTNER_NAME");
        $this->PARTNER_URI = Loc::getMessage("NAUTILUS_BIDS_PARTNER_URI");

        $this->MODULE_SORT = 1;
        $this->SHOW_SUPER_ADMIN_GROUP_RIGHTS='Y';
        $this->MODULE_GROUP_RIGHTS = "Y";
    }

    public function isVersionD7()
    {
        return CheckVersion(\Bitrix\Main\ModuleManager::getVersion('main'), '14.00.00');
    }

    public function GetPath($notDocumentRoot=false)
    {
        if($notDocumentRoot)
            return str_ireplace(Application::getDocumentRoot(),'',dirname(__DIR__));
        else
            return dirname(__DIR__);
    }


    function InstallFiles($arParams = array())
    {

        if (\Bitrix\Main\IO\Directory::isDirectoryExists($path = $this->GetPath() . '/admin/'))
        {
            //Здесь не понятно с копированием. Сейчас модуль находится в папке local. И получается что из local копируется в папку /bitrix/modules/
            //Но когда модуль будет устанавливатся их маркетплейса, он сразу будет расположен в папке /bitrix/modules/ - значит такое копирование не нужно?
            //Речь идет о файле с меню
            CopyDirFiles($this->GetPath() . "/admin/menu.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/".$this->MODULE_ID."/admin/menu.php");
            CopyDirFiles($this->GetPath() . "/lang/ru/admin/menu.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/".$this->MODULE_ID."/lang/ru/admin/menu.php");

            CopyDirFiles($this->GetPath() . "/admin/bids_result_list.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/bids_result_list.php");
            CopyDirFiles($this->GetPath() . "/bids_result_list.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/".$this->MODULE_ID."/bids_result_list.php");

            CopyDirFiles($this->GetPath() . "/admin/bids_edit.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/bids_edit.php");
            CopyDirFiles($this->GetPath() . "/bids_edit.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/".$this->MODULE_ID."/bids_edit.php");

            CopyDirFiles($this->GetPath() . "/admin/bids_ajax.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/bids_ajax.php");
            CopyDirFiles($this->GetPath() . "/bids_ajax.php", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/".$this->MODULE_ID."/bids_ajax.php");

        }

        return true;
    }
    function UnInstallFiles()
    {

        if (\Bitrix\Main\IO\Directory::isDirectoryExists($path = $this->GetPath() . '/admin')) {
            Bitrix\Main\IO\Directory::deleteDirectory($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/".$this->MODULE_ID);
            Bitrix\Main\IO\Directory::deleteDirectory($_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/bids_result_list.php");
            Bitrix\Main\IO\Directory::deleteDirectory($_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin/bids_edit.php");
        }
    }

    function InstallDB()
    {
        Loader::includeModule($this->MODULE_ID);

        if(!Application::getConnection()->isTableExists(
            Base::getInstance('\Nautilus\Bids\BidsTable')->getDBTableName()
        )
        )
        {
            Base::getInstance('\Nautilus\Bids\BidsTable')->createDbTable();
        }

        if(!Application::getConnection()->isTableExists(
            Base::getInstance('\Nautilus\Bids\TypeTable')->getDBTableName()
        )
        )
        {
            Base::getInstance('\Nautilus\Bids\TypeTable')->createDbTable();
        }

        if(!Application::getConnection()->isTableExists(
            Base::getInstance('\Nautilus\Bids\CategoryTable')->getDBTableName()
        )
        )
        {
            Base::getInstance('\Nautilus\Bids\CategoryTable')->createDbTable();
        }

        if(!Application::getConnection()->isTableExists(
            Base::getInstance('\Nautilus\Bids\BrandsTable')->getDBTableName()
        )
        )
        {
            Base::getInstance('\Nautilus\Bids\BrandsTable')->createDbTable();
        }

        if(!Application::getConnection()->isTableExists(
            Base::getInstance('\Nautilus\Bids\CountryTable')->getDBTableName()
        )
        )
        {
            Base::getInstance('\Nautilus\Bids\CountryTable')->createDbTable();
        }

        if(!Application::getConnection()->isTableExists(
            Base::getInstance('\Nautilus\Bids\CityTable')->getDBTableName()
        )
        )
        {
            Base::getInstance('\Nautilus\Bids\CityTable')->createDbTable();
        }
    }

    function UnInstallDB()
    {
        Loader::includeModule($this->MODULE_ID);

        Application::getConnection(\Nautilus\Bids\BidsTable::getConnectionName())->
        queryExecute('drop table if exists '.Base::getInstance('\Nautilus\Bids\BidsTable')->getDBTableName());

        Application::getConnection(\Nautilus\Bids\TypeTable::getConnectionName())->
        queryExecute('drop table if exists '.Base::getInstance('\Nautilus\Bids\TypeTable')->getDBTableName());

        Application::getConnection(\Nautilus\Bids\CategoryTable::getConnectionName())->
        queryExecute('drop table if exists '.Base::getInstance('\Nautilus\Bids\CategoryTable')->getDBTableName());

        Application::getConnection(\Nautilus\Bids\CategoryTable::getConnectionName())->
        queryExecute('drop table if exists '.Base::getInstance('\Nautilus\Bids\BrandsTable')->getDBTableName());

        Application::getConnection(\Nautilus\Bids\CategoryTable::getConnectionName())->
        queryExecute('drop table if exists '.Base::getInstance('\Nautilus\Bids\CountryTable')->getDBTableName());

        Application::getConnection(\Nautilus\Bids\CategoryTable::getConnectionName())->
        queryExecute('drop table if exists '.Base::getInstance('\Nautilus\Bids\CityTable')->getDBTableName());

        Option::delete($this->MODULE_ID);
    }

    function DoInstall()
    {
        global $APPLICATION;
        if($this->isVersionD7())
        {
            \Bitrix\Main\ModuleManager::registerModule($this->MODULE_ID);
            $this->InstallDB();
            $this->InstallFiles();
            setBidsType();
            setBidsCategory();
            setBidsBrands();
            setCountryBids();
            setCityBids();
            setExampleBids();
            setOptionBidsList($this->MODULE_ID);

        }
        else
        {
            $APPLICATION->ThrowException(Loc::getMessage("NAUTILUS_BIDS_INSTALL_ERROR_VERSION"));
        }

        $APPLICATION->IncludeAdminFile(Loc::getMessage("NAUTILUS_BIDS_INSTALL_TITLE"), $this->GetPath()."/install/step.php");
    }

    function DoUninstall()
    {
        global $APPLICATION;

        $context = Application::getInstance()->getContext();
        $request = $context->getRequest();
        $this->UnInstallFiles();

        if($request["step"]<2)
        {
            $APPLICATION->IncludeAdminFile(Loc::getMessage("NAUTILUS_BIDS_UNINSTALL_TITLE"), $this->GetPath()."/install/unstep1.php");
        }
        elseif($request["step"]==2)
        {           

            if($request["savedata"] != "Y")
                $this->UnInstallDB();

            \Bitrix\Main\ModuleManager::unRegisterModule($this->MODULE_ID);

            $APPLICATION->IncludeAdminFile(Loc::getMessage("NAUTILUS_BIDS_UNINSTALL_TITLE"), $this->GetPath()."/install/unstep2.php");
        }
    }

}
