<?php
$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2021-06-14 00:00:00"
);
?>