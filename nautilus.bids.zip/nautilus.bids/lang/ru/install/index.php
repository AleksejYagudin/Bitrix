<?
$MESS["NAUTILUS_BIDS_MODULE_NAME"] = "Заявки";
$MESS["NAUTILUS_BIDS_MODULE_DESC"] = "Заявки на покупку/продажу/аренду/услуги";
$MESS["NAUTILUS_BIDS_PARTNER_NAME"] = "Алексей Ягудин";
$MESS["NAUTILUS_BIDS_PARTNER_URI"] = "https://alex644";

$MESS["NAUTILUS_BIDS_DENIED"] = "Доступ закрыт";
$MESS["NAUTILUS_BIDS_READ_COMPONENT"] = "Доступ к компонентам";
$MESS["NAUTILUS_BIDS_WRITE_SETTINGS"] = "Изменение настроек модуля";
$MESS["NAUTILUS_BIDS_FULL"] = "Полный доступ";

$MESS["NAUTILUS_BIDS_INSTALL_TITLE"] = "Установка модуля";
$MESS["NAUTILUS_BIDS_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста обновите систему.";

$MESS["NAUTILUS_BIDS_NO_CACHE"] = 'Внимание, на сайте выключено кеширование!<br>Возможно замедление в работе модуля.';

?>