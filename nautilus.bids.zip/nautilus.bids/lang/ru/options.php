<?php
$MESS["NAUTILUS_BIDS_TAB_SETTINGS"] = "Управление";
$MESS["NAUTILUS_BIDS_TAB_CONTROL"] = "Администрирование";
$MESS["NAUTILUS_BIDS_TYPE_1"] = "Продажа";
$MESS["NAUTILUS_BIDS_TYPE_2"] = "Аренда";
$MESS["NAUTILUS_BIDS_TYPE_3"] = "Запчасти";
$MESS["NAUTILUS_BIDS_TYPE_4"] = "Ремонт и сервис";
$MESS["NAUTILUS_BIDS_TYPE_5"] = "Кредит/Лизинг";
$MESS["NAUTILUS_BIDS_TYPE_6"] = "Перевозка";
$MESS["NAUTILUS_BIDS_TYPE_7"] = "Услуги";
