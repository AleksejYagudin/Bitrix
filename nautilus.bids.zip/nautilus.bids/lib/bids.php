<?php
namespace Nautilus\Bids;

use \Bitrix\Main\Entity;
use \Bitrix\Main\Type;
use \Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);


class BidsTable extends Entity\DataManager
{
    public static function getTableName()
    {
        return 'bids_table';
    }

    public static function getMap()
    {
        return array(
            //ID
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            //Дата заявки
            new Entity\DateField('PUBLISH_DATE', array(
                'default_value' => new Type\Date,
            )),
            //Тип
            new Entity\IntegerField('TYPE_ID', array(
                'required' => true,
            )),
            new Entity\ReferenceField(
                'TYPE',
                '\Nautilus\Bids\TypeTable',
                array('=this.TYPE_ID' => 'ref.ID')
            ),
            //Категория
            new Entity\IntegerField('CATEGORY_ID', array()),
            new Entity\ReferenceField(
                'CATEGORY',
                '\Nautilus\Bids\CategoryTable',
                array('=this.CATEGORY_ID' => 'ref.ID'),
            ),
            //Бренд
            new Entity\IntegerField('BRAND_ID', array()),
            new Entity\ReferenceField(
                'BRAND',
                '\Nautilus\Bids\BrandsTable',
                array('=this.BRAND_ID' => 'ref.ID'),
            ),
            //Страна
            new Entity\IntegerField('COUNTRY_ID', array()),
            new Entity\ReferenceField(
                'COUNTRY',
                '\Nautilus\Bids\CountryTable',
                array('=this.COUNTRY_ID' => 'ref.ID'),
            ),
            //Город
            new Entity\StringField('CITY', array('required' => true)),

            //Состояние
            new Entity\EnumField('STATUS', array(
                'values' => array(Loc::getMessage("NAUTILUS_BIDS_ENUM_VALUE1"), Loc::getMessage("NAUTILUS_BIDS_ENUM_VALUE2"), Loc::getMessage("NAUTILUS_BIDS_ENUM_VALUE3")),
                'default_value' => Loc::getMessage("NAUTILUS_BIDS_ENUM_VALUE1")
            )),
            //Сумма от
            new Entity\IntegerField('PRICE_MIN', array()),
            //Сумма до
            new Entity\IntegerField('PRICE_MAX', array()),
            //Пользователь
            new Entity\StringField('USER', array(
                'required' => true,
            )),
            //Эл. почта
            new Entity\StringField('EMAIL', array(
                'validation' => function() {
                    return array(
                        function ($value, $primary, $row, $field)
                        {
                            if (filter_var($value, FILTER_VALIDATE_EMAIL) !== false)
                            {
                                return true;
                            }
                            else
                            {
                                return new Entity\FieldError(
                                    $field, Loc::getMessage("NAUTILUS_BIDS_WRONG_EMAIL"), 'WRONG_EMAIL');
                            }
                        }
                    );
                }
            )),
            //Телефон
            new Entity\StringField('PHONE', array(
                'validation' => function() {
                    return array(
                        new Entity\Validator\RegExp('/^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$/')
                    );
                }
            )),
            //Название
            new Entity\StringField('NAME', array(
                'required' => true,
            )),
            //Описание
            new Entity\TextField('DESCRIPTION', array(
                'required' => true,
            )),
            //Активация
            new Entity\BooleanField('ACTIVE', array(
                'values' => array('N', 'Y')
            )),

        );
    }
}
