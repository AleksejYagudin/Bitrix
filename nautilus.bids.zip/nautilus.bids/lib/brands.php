<?php
namespace Nautilus\Bids;

use \Bitrix\Main\Entity;


class BrandsTable extends Entity\DataManager
{
    public static function getTableName()
    {
        return 'bids_brands';
    }

    public static function getMap()
    {
        return array(
            //ID
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            //Название
            new Entity\StringField('NAME', array(
                'required' => true,
            )),
            //Активация
            new Entity\BooleanField('ACTIVE', array(
                'values' => array('N', 'Y')
            )),
            //Популярность
            new Entity\BooleanField('POPULAR', array(
                'values' => array('N', 'Y')
            )),
            //Сортировка
            new Entity\IntegerField('SORT', array(
                'required' => true,
            )),


        );
    }
}

