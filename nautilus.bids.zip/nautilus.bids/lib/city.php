<?php
namespace Nautilus\Bids;

use \Bitrix\Main\Entity;


class CityTable extends Entity\DataManager
{
    public static function getTableName()
    {
        return 'bids_city';
    }

    public static function getMap()
    {
        return array(
            //ID
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            //Страна
            new Entity\IntegerField('COUNTRY_ID', array(
                'required' => true,
            )),
            new Entity\ReferenceField(
                'COUNTRY',
                '\Nautilus\Bids\CountryTable',
                array('=this.COUNTRY_ID' => 'ref.ID')
            ),
            //Название
            new Entity\StringField('NAME', array(
                'required' => true,
            )),

        );
    }
}

