<?php
namespace Nautilus\Bids;

use \Bitrix\Main\Entity;


class CountryTable extends Entity\DataManager
{
    public static function getTableName()
    {
        return 'bids_country';
    }

    public static function getMap()
    {
        return array(
            //ID
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            //Название
            new Entity\StringField('NAME', array(
                'required' => true,
            )),

        );
    }
}