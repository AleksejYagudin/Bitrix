<?php
namespace Nautilus\Bids;
class helperBids
{
    public static function getType()
    {
        $res = TypeTable::getList(
            array(
                'filter' => array(
                    '=ACTIVE' => 'Y'
                )
            )
        );
        while ($ar_res = $res->fetch())
        {
            $type[] = $ar_res;
        }
        return $type;
    }
    public static function getTypeID()
    {
        $res = TypeTable::getList(
            array(
                'filter' => array(
                    '=ACTIVE' => 'Y'
                )
            )
        );
        while ($ar_res = $res->fetch())
        {
            $typeID[] = $ar_res['ID'];
        }
        return $typeID;
    }

    public static function getTypeName()
    {
        $res = TypeTable::getList();
        while ($ar_res = $res->fetch())
        {
            $typeName[] = $ar_res['NAME'];
        }
        return $typeName;
    }
    public static function getTypeListName($id)
    {
        $type = self::getType();
        $html = '<select name="type-list" style="width: 250px;">';
        foreach ($type as $arItem)
        {
            if($arItem['ID'] == $id)
            {
                $html .= '<option selected value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }
            else
            {
                $html .= '<option value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }

        }
        $html .= '</select>';
        return $html;
    }


    public static function getStatus()
    {
        $res = BidsTable::getEntity()->getField('STATUS')->getValues();

        foreach ($res as $arItem)
        {
            $result[] = $arItem;
        }
        return $result;
    }
    public static function getStatusListName($name)
    {
        $status = self::getStatus();
        $html = '<select name="status-list" style="width: 250px;">';
        foreach ($status as $arItem)
        {
            if($arItem == $name)
            {
                $html .= '<option selected value = "' .$arItem. '">'.$arItem.'</option>';
            }
            else
            {
                $html .= '<option value = "' .$arItem. '">'.$arItem.'</option>';
            }

        }
        $html .= '</select>';
        return $html;
    }


    public static function getCategoryListAll()
    {
        $res = CategoryTable::getList()->fetchAll();
        return $res;
    }
    public static function getCategoryList()
    {
        $res = CategoryTable::getList(
           array(
                'filter' => array(
                    '=ACTIVE' => 'Y'
                ),
            )
        );
        while ($ar_res = $res->fetch())
        {
            $category[] = $ar_res;
        }
        return $category;

    }
    public static function getCategoryListName($id)
    {
       $category = self::getCategoryList();
       $html = '<select name="category-list" style="width: 250px;">';
       foreach ($category as $arItem)
       {
            if($arItem['ID'] == $id)
            {
                $html .= '<option selected value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }
            else
            {
                $html .= '<option value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }

       }
       $html .= '</select>';
       return $html;
    }
    public static function dellCategory($id)
    {
        $result = CategoryTable::delete($id);
        if($result)
        {
            return true;
        }
        else
            return false;
    }

    public static function getBrandListAll()
    {
        $res = BrandsTable::getList()->fetchAll();
        return $res;
    }
    public static function getBrandsList()
    {
        $res = BrandsTable::getList(
            array(
                'filter' => array(
                    '=ACTIVE' => 'Y'
                )
            )
        );
        while ($ar_res = $res->fetch())
        {
            $brands[] = $ar_res;
        }
        return $brands;

    }
    public static function getBrandsListName($id)
    {
        $brand = self::getBrandsList();
        $html = '<select name="brand-list" style="width: 250px;">';
        foreach ($brand as $arItem)
        {
            if($arItem['ID'] == $id)
            {
                $html .= '<option selected value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }
            else
            {
                $html .= '<option value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }

        }
        $html .= '</select>';
        return $html;
    }
    public static function dellBrand($id)
    {
        $result = BrandsTable::delete($id);
        if($result)
        {
            return true;
        }
        else
            return false;
    }

    public static function getCountryList()
    {
        $res = CountryTable::getList();
        while ($ar_res = $res->fetch())
        {
            $countrys[] = $ar_res;
        }
        return $countrys;

    }
    public static function getCountryListName($id)
    {
        $country = self::getCountryList();
        $html = '<select name="country-list" style="width: 250px;">';
        foreach ($country as $arItem)
        {
            if($arItem['ID'] == $id)
            {
                $html .= '<option selected value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }
            else
            {
                $html .= '<option value = "' .$arItem['ID']. '">'.$arItem['NAME'].'</option>';
            }

        }
        $html .= '</select>';
        return $html;
    }

    public static function getCityList()
    {
        $res = CityTable::getList();
        while ($ar_res = $res->fetch())
        {
            $city[] = $ar_res;
        }
        return $city;

    }
    public static function getCityName($country_id = '', $city_name = '')
    {
        $city = self::getCityList();

        $html = '<select name="city-list" style="width: 250px;">';


        if($country_id !== '')
        {
            foreach ($city as $arItem)
            {
                if($arItem['COUNTRY_ID'] == $country_id)
                {
                    $html .= '<option value = "' .$arItem['NAME']. '">'.$arItem['NAME'].'</option>';
                }
            }
        }

        if($city_name !== '')
        {
            foreach ($city as $arItem)
            {
                if($arItem['NAME'] == $city_name && $arItem['COUNTRY_ID'] == $country_id)
                {
                    $html .= '<option selected value = "' .$arItem['NAME']. '">'.$arItem['NAME'].'</option>';
                }
                elseif($arItem['COUNTRY_ID'] == $country_id)
                {
                    $html .= '<option value = "' .$arItem['NAME']. '">'.$arItem['NAME'].'</option>';
                }
            }
        }
        $html .= '</select>';
        return $html;

    }

   public static function getActive($arr)
    {

        $type = self::getType();
        $typeTemp = array();
        foreach ($type as $arItem)
        {
            $typeTemp[] = $arItem['NAME'];
        }
        $category = self::getCategoryList();
        $categoryTemp = array();
        foreach ($category as $arItem)
        {
            $categoryTemp[] = $arItem['NAME'];
        }
        $brand = self::getBrandsList();
        $brandTemp = array();
        foreach ($brand as $arItem)
        {
            $brandTemp[] = $arItem['NAME'];
        }

        if(in_array($arr['TYPE_NAME'],$typeTemp) && in_array($arr['CATEGORY_NAME'],$categoryTemp) && in_array($arr['BRAND_NAME'],$brandTemp))
        {
            return true;
        }
        else
        {
            return false;
        }

    }

}