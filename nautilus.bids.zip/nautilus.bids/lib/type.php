<?php
namespace Nautilus\Bids;

use \Bitrix\Main\Entity;


class TypeTable extends Entity\DataManager
{
    public static function getTableName()
    {
        return 'bids_type';
    }

    public static function getMap()
    {
        return array(
            //ID
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            //Название
            new Entity\StringField('NAME', array(
                'required' => true,
            )),
            //Активность
            new Entity\BooleanField('ACTIVE', array(
                'values' => array('N', 'Y')
            )),
            //Сортировка
            new Entity\IntegerField('SORT', array()),

        );
    }
}

