<?php

use Bitrix\Main\HttpApplication;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Config\Option;
use Nautilus\Bids\CategoryTable;
use Nautilus\Bids\TypeTable;
use Nautilus\Bids\BrandsTable;


$module_id = 'nautilus.bids';

Loc::loadMessages($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/options.php");
Loc::loadMessages(__FILE__);

Loader::includeModule($module_id);

$request = HttpApplication::getInstance()->getContext()->getRequest();

$aTabs = array(
    array(
        "DIV" => "edit1",
        "TAB" => Loc::getMessage("NAUTILUS_BIDS_TAB_CONTROL"),
        "TITLE" => Loc::getMessage("NAUTILUS_BIDS_TAB_CONTROL")
    ),
    array(
        "DIV" => "edit2",
        "TAB" => Loc::getMessage("MAIN_TAB_RIGHTS"),
        "TITLE" => Loc::getMessage("MAIN_TAB_TITLE_RIGHTS")
    ),

);

#Сохранение

if ($request->isPost() && $request['Update'] && check_bitrix_sessid())
{

    foreach ($aTabs as $aTab)
    {

        foreach ($aTab['OPTIONS'] as $arOption)
        {
            if (!is_array($arOption))
                continue;

            if ($arOption['note'])
                continue;

            $optionName = $arOption[0];

            $optionValue = $request->getPost($optionName);

            Option::set($module_id, $optionName, is_array($optionValue) ? implode(",", $optionValue):$optionValue);
            $typeId = str_replace('TYPE_', '', $arOption[0]);

        }
    }

    $arrTypes = array();
    $resType = TypeTable::getList(array(
        'order' => array('SORT' => 'ASC')
    ));
    while ($arType = $resType->fetch())
    {
        $arrTypes[] = $arType;
    }
    $updateTypes = array();
    $countTypes = count($arrTypes);
    for ($i = 1; $i <= $countTypes; $i++) {
        $updateTypes[$i]['ID'] = $i;
        $updateTypes[$i]['NAME'] = $request['type_name_' . $i];
        $updateTypes[$i]['ACTIVE'] = ($request['type_active_' . $i]) ? 'Y' : 'N';
        $updateTypes[$i]['SORT'] = $request['type_sort_' . $i];
    }

    foreach ($updateTypes as $arItem) {
        $arFields = array(
            'NAME' => $arItem['NAME'],
            'ACTIVE' => $arItem['ACTIVE'],
            'SORT' => $arItem['SORT'],
        );
        TypeTable::update($arItem['ID'], $arFields);
    }
//Сохраняем категории
    $catArray = array();
    foreach ($request->getValues() as $key => $arItem)
    {
        if(strpos($key, "cat_") !==false)
        {

            if(strpos($key, "cat_name_") !==false)
            {
                $idCat = str_replace("cat_name_", "", $key);

            }

                $catArray[$idCat][$key] = $arItem;
        }
    }

foreach ($catArray as $key1 => $arItem1)
{
    foreach ($arItem1 as $key2 => $arItem2)
    {
        $arFields = array(
            'NAME' => $request->getValues()["cat_name_".$key1],
            'ACTIVE' => ($request->getValues()["cat_active_".$key1] == null) ? 'N':'Y',
            'POPULAR' => ($request->getValues()["cat_popular_".$key1] == null) ? 'N':'Y',
            'SORT' => ($request->getValues()["cat_sort_".$key1] == null) ? '500':$request->getValues()["cat_sort_".$key1],
        );
    }
    CategoryTable::update($key1, $arFields);
}

//Сохраняем бренды
    $brandArray = array();
    foreach ($request->getValues() as $key => $arItem)
    {
        if(strpos($key, "brand_") !==false)
        {

            if(strpos($key, "brand_name_") !==false)
            {
                $idBrand = str_replace("brand_name_", "", $key);

            }

            $brandArray[$idBrand][$key] = $arItem;
        }
    }

    foreach ($brandArray as $key1 => $arItem1)
    {
        foreach ($arItem1 as $key2 => $arItem2)
        {
            $arFields = array(
                'NAME' => $request->getValues()["brand_name_".$key1],
                'ACTIVE' => ($request->getValues()["brand_active_".$key1] == null) ? 'N':'Y',
                'POPULAR' => ($request->getValues()["brand_popular_".$key1] == null) ? 'N':'Y',
                'SORT' => ($request->getValues()["brand_sort_".$key1] == null) ? '500':$request->getValues()["brand_sort_".$key1],
            );
        }
        BrandsTable::update($key1, $arFields);
    }

    if(!isset($request['option_category']))
    {
        Option::set($module_id, "CATEGORY", "N");
    }
    else
    {
        Option::set($module_id, "CATEGORY", "Y");
    }
    if(!isset($request['option_brand']))
    {
        Option::set($module_id, "BRAND", "N");
    }
    else
    {
        Option::set($module_id, "BRAND", "Y");
    }
    if(!isset($request['option_email']))
    {
        Option::set($module_id, "EMAIL", "N");
    }
    else
    {
        Option::set($module_id, "EMAIL", "Y");
    }
    if(!isset($request['option_phone']))
    {
        Option::set($module_id, "PHONE", "N");
    }
    else
    {
        Option::set($module_id, "PHONE", "Y");
    }
}


#Визуальный вывод

$tabControl = new CAdminTabControl('tabControl', $aTabs);

?>
<style>
    .scroll-table-body {
        height: 300px;

        overflow-x: auto;
        margin-top: 0px;
        margin-bottom: 20px;
        border-bottom: 1px solid #eee;
    }
    .scroll-table table {
        width:100%;
        table-layout: fixed;
        border: none;
    }
    .scroll-table thead th {
        font-weight: bold;
        text-align: left;
        border: none;
        padding: 10px 15px;
        background: #d8d8d8;
        font-size: 14px;
        border-left: 1px solid #ddd;
        border-right: 1px solid #ddd;
    }
    .scroll-table tbody td {
        text-align: left;
        border-left: 1px solid #ddd;
        border-right: 1px solid #ddd;
        padding: 10px 15px;
        font-size: 14px;
        vertical-align: top;
    }
    .scroll-table tbody tr:nth-child(even){
        background: #f3f3f3;
    }

    .option_item{
        text-align: center;
    }
    .option_item span{
        padding-right: 5px;
    }


</style>
<? $tabControl->Begin(); ?>
<form method='post' action='<?echo $APPLICATION->GetCurPage()?>?mid=<?=htmlspecialcharsbx($request['mid'])?>&amp;lang=<?=$request['lang']?>' name='nautilus_bids_settings'>


    <?
    $tabControl->BeginNextTab();
    ?>
    <?

    $resOptions = Option::getForModule(
        'nautilus.bids',
        false
    );
    ?>
    <tr class="heading"><td colspan="2">Опции:</td></tr>
    <tr>
        <td>
            <div class="option_item">
            <span><input type="checkbox" name="option_category"<?if($resOptions['CATEGORY'] == 'Y'):?>checked<?endif;?>/>Категории</span>
            <span><input type="checkbox" name="option_brand"<?if($resOptions['BRAND'] == 'Y'):?>checked<?endif;?>/>Бренд</span>
            <span><input type="checkbox" name="option_email"<?if($resOptions['EMAIL'] == 'Y'):?>checked<?endif;?>/>Эл. почта</span>
            <span><input type="checkbox" name="option_phone"<?if($resOptions['PHONE'] == 'Y'):?>checked<?endif;?>/>Телефон</span>
            </div>
        </td>
    </tr>
    <?

    $arrTypes = array();
    $resType = TypeTable::getList(array(

    ));
    while ($arType = $resType->fetch()) {
        $arrTypes[] = $arType;
    }
    ?>
    <tr class="heading"><td colspan="2">Типы:</td></tr>
    <td colspan="2">
        <div class="scroll-table">
            <table>
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Активность</th>
                    <th>Сортировка</th>
                </tr>
                </thead>
            </table>
            <div class="scroll-table-body">
                <table>
                    <tbody>
                    <?foreach ($arrTypes as $key => $arItem):?>
                        <tr>
                            <td><input type="text" name="type_name_<?=$arItem['ID']?>" value="<?=$arItem['NAME']?>"></td>
                            <td><input type="checkbox" name="type_active_<?=$arItem['ID']?>"<?if($arItem['ACTIVE'] == 'Y'):?>checked<?endif;?>/>Активность</td>
                            <td><input type="text" name="type_sort_<?=$arItem['ID']?>" value="<?=$arItem['SORT']?>"></td>
                        </tr>
                    <?endforeach;?>
                    </tbody>
                </table>
            </div>
        </div>
    </td>

    <td>
        <tr class="heading"><td colspan="2">Категории:</td></tr>
        <?
        $arrCategory = array();
        $resCat = CategoryTable::getList(array(
            'order' => array('SORT' => 'ASC')
        ));
        while ($arCat = $resCat->fetch())
        {
            $arrCategory[] = $arCat;
        }

        ?>

    <td colspan="2" style="text-align: left">
        <div class="scroll-table">
            <table>
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Активность</th>
                    <th>Популярность</th>
                    <th>Сортировка</th>
                </tr>
                </thead>
            </table>
            <div class="scroll-table-body" id = "category-table">
                <table>
                    <tbody>
                    <?foreach ($arrCategory as $key => $arItem):?>
                        <tr>
                            <td><input type="text" name="cat_name_<?=$arItem['ID']?>" value="<?=$arItem['NAME']?>"> <span class="bx-core-popup-menu-item-icon adm-menu-delete" style="display: inline-block; position: unset; vertical-align: middle; cursor: pointer" data-name = "category-dell" data-id = "<?=$arItem['ID']?>"></td>
                            <td><input type="checkbox" name="cat_active_<?=$arItem['ID']?>"<?if($arItem['ACTIVE'] == 'Y'):?>checked<?endif;?>/>Активность</td>
                            <td><input type="checkbox" name="cat_popular_<?=$arItem['ID']?>"<?if($arItem['POPULAR'] == 'Y'):?>checked<?endif;?>/>Популярность</td>
                            <td><input type="text" name="cat_sort_<?=$arItem['ID']?>" value="<?=$arItem['SORT']?>"></td>
                        </tr>
                    <?endforeach;?>
                    </tbody>
                </table>
            </div>
            <span class="adm-btn adm-btn-save adm-btn-add" title="Добавить заявку" data-name="add-category">Добавить категорию</span>
        </div>

    </td>
    <td>
        <tr class="heading"><td colspan="2">Бренды:</td></tr>
        <?
        $arrBrands = array();
        $resBrands = BrandsTable::getList(array(
            'order' => array('SORT' => 'ASC')
        ));
        while ($arBrand = $resBrands->fetch())
        {
            $arrBrands[] = $arBrand;
        }

        ?>
    </td>
    <td colspan="2" style="text-align: left">
        <div class="scroll-table">
            <table>
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Активность</th>
                    <th>Популярность</th>
                    <th>Сортировка</th>
                </tr>
                </thead>
            </table>
            <div class="scroll-table-body" id = "brand-table">
                <table>
                    <tbody>
                    <?foreach ($arrBrands as $key => $arItem):?>
                        <tr>
                            <td><input type="text" name="brand_name_<?=$arItem['ID']?>" value="<?=$arItem['NAME']?>"><span class="bx-core-popup-menu-item-icon adm-menu-delete" style="display: inline-block; position: unset; vertical-align: middle; cursor: pointer" data-name = "brand-dell" data-id = "<?=$arItem['ID']?>"></td>
                            <td><input type="checkbox" name="brand_active_<?=$arItem['ID']?>"<?if($arItem['ACTIVE'] == 'Y'):?>checked<?endif;?>/>Активность</td>
                            <td><input type="checkbox" name="brand_popular_<?=$arItem['ID']?>"<?if($arItem['POPULAR'] == 'Y'):?>checked<?endif;?>/>Популярность</td>
                            <td><input type="text" name="brand_sort_<?=$arItem['ID']?>" value="<?=$arItem['SORT']?>"></td>
                        </tr>
                    <?endforeach;?>
                    </tbody>
                </table>
            </div>
            <span class="adm-btn adm-btn-save adm-btn-add" title="Добавить заявку" data-name="add-brand">Добавить бренд</span>
        </div>
    </td>


    <?
    $tabControl->BeginNextTab();

    require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/group_rights.php");
    ?>
    <?$tabControl->Buttons();?>
    <input type="submit" name="Update" value="<?echo GetMessage('MAIN_SAVE')?>">
    <input type="reset" name="reset" value="<?echo GetMessage('MAIN_RESET')?>">
    <?=bitrix_sessid_post();?>

</form>
<? $tabControl->End(); ?>

<script>
 let scrollTableBody = document.querySelectorAll('.scroll-table-body'),
     scrollTable = document.querySelectorAll('.scroll-table');
 scrollTableBody.forEach(function (item){
     item.addEventListener('click', function (e){
         if(e.target.getAttribute('data-name') === 'category-dell')
         {
             let categoryId = e.target.getAttribute('data-id'),
                 categoryName = e.target.previousElementSibling.value;
             var btn_dell_cat = {
                 title: BX.message('JS_CORE_WINDOW_SAVE'),
                 id: 'dellbtncat',
                 name: 'dellbtncat',
                 className: BX.browser.IsIE() && BX.browser.IsDoctype() && !BX.browser.IsIE10() ? '' : 'adm-btn-save',
                 action: function () {
                     BX.ajax({
                         url: '/bitrix/admin/bids_ajax.php',
                         data: {
                             target: 'categoryDell',
                             categoryId: categoryId
                         },
                         method: 'POST',
                         dataType: 'json',
                         onsuccess: function (data) {
                             if(data === 'ok')
                             {
                                 e.target.parentNode.parentNode.remove();
                             }
                         },
                         onfailure: function () {
                             console.error(data);
                         }
                     });
                     this.parentWindow.Close();
                 }
             };

             var popupCat = new BX.CDialog({
                 'title': `Удаление категории ${categoryName}`,
                 'content': `Удалить категорию <b>${categoryName}</b> и заявки использующие эту категорию?`,
                 'draggable': true,
                 'resizable': true,
                 'width': 500,
                 'height': 100,
                 'buttons': [btn_dell_cat, BX.CDialog.btnCancel]
             });
             popupCat.Show();
         };
         if(e.target.getAttribute('data-name') === 'brand-dell')
         {
             let brandId = e.target.getAttribute('data-id'),
                 brandName = e.target.previousElementSibling.value;
             var btn_dell_brand = {
                 title: BX.message('JS_CORE_WINDOW_SAVE'),
                 id: 'dellbtnbrand',
                 name: 'dellbtnbrand',
                 className: BX.browser.IsIE() && BX.browser.IsDoctype() && !BX.browser.IsIE10() ? '' : 'adm-btn-save',
                 action: function () {
                     BX.ajax({
                         url: '/bitrix/admin/bids_ajax.php',
                         data: {
                             target: 'brandDell',
                             brandId: brandId
                         },
                         method: 'POST',
                         dataType: 'json',
                         onsuccess: function (data) {
                             if(data === 'ok')
                             {
                                 e.target.parentNode.parentNode.remove();
                             }
                         },
                         onfailure: function () {
                             console.error(data);
                         }
                     });
                     this.parentWindow.Close();
                 }
             };

             var popupBrand = new BX.CDialog({
                 'title': `Удаление бренда ${brandName}`,
                 'content': `Удалить бренд <b>${brandName}</b> и заявки использующие этот бренд?`,
                 'draggable': true,
                 'resizable': true,
                 'width': 500,
                 'height': 100,
                 'buttons': [btn_dell_brand, BX.CDialog.btnCancel]
             });
             popupBrand.Show();

         }

     });
 });
 scrollTable.forEach(function (item){
     item.addEventListener('click', function (e){
         if(e.target.getAttribute('data-name') === 'add-category')
         {
             BX.ajax({
                 url: '/bitrix/admin/bids_ajax.php',
                 data: {
                     target: 'addCategory',
                 },
                 method: 'POST',
                 dataType: 'json',
                 onsuccess: function (data) {
                     let nextCategory = data,
                         categoryTable = document.querySelector('#category-table tbody'),
                         TR = categoryTable.querySelector('tr'),
                         cloneTR = TR.cloneNode(true),
                         cloneTD = cloneTR.childNodes;
                     cloneTD.forEach(function (item, key){
                        if(item.tagName === 'TD')
                        {
                            if(key === 1)
                            {
                                let inputTD = item.querySelector('input'),
                                    spanTD = item.querySelector('span');

                                inputTD.setAttribute('name', 'cat_name_'+nextCategory['ID']);
                                inputTD.value = nextCategory['DATA']['NAME'];
                                spanTD.setAttribute('data-id', nextCategory['ID']);
                            }
                            if(key === 3)
                            {
                                let inputTD = item.querySelector('input');
                                inputTD.setAttribute('name', 'cat_active_'+nextCategory['ID']);
                                inputTD.removeAttribute('checked');
                                inputTD.setAttribute('id', 'cat_active_'+nextCategory['ID']);
                                inputTD.checked = false;
                                inputTD.nextElementSibling.setAttribute('for', 'cat_active_'+nextCategory['ID']);

                            }
                            if(key === 5)
                            {
                                let inputTD = item.querySelector('input');
                                inputTD.setAttribute('name', 'cat_popular_'+nextCategory['ID']);
                                inputTD.setAttribute('id', 'cat_popular_'+nextCategory['ID']);
                                inputTD.checked = false;
                                inputTD.nextElementSibling.setAttribute('for', 'cat_popular_'+nextCategory['ID']);



                            }
                            if(key === 7)
                            {
                                let inputTD = item.querySelector('input');
                                inputTD.setAttribute('name', 'cat_sort_'+nextCategory['ID']);
                                inputTD.value = 500;
                            }
                        }

                     });
                     categoryTable.append(cloneTR);

                 },
                 onfailure: function () {
                     console.error(data);
                 }
             });
         }
         if(e.target.getAttribute('data-name') === 'add-brand')
         {
             BX.ajax({
                 url: '/bitrix/admin/bids_ajax.php',
                 data: {
                     target: 'addBrand',
                 },
                 method: 'POST',
                 dataType: 'json',
                 onsuccess: function (data) {
                     let nextBrand = data,
                         brandTable = document.querySelector('#brand-table tbody'),
                         TR = brandTable.querySelector('tr'),
                         cloneTR = TR.cloneNode(true),
                         cloneTD = cloneTR.childNodes;
                     cloneTD.forEach(function (item, key){
                         if(item.tagName === 'TD')
                         {
                             if(key === 1)
                             {
                                 let inputTD = item.querySelector('input'),
                                     spanTD = item.querySelector('span');

                                 inputTD.setAttribute('name', 'brand_name_'+nextBrand['ID']);
                                 inputTD.value = nextBrand['DATA']['NAME'];
                                 spanTD.setAttribute('data-id', nextBrand['ID']);
                             }
                             if(key === 3)
                             {
                                 let inputTD = item.querySelector('input');
                                 inputTD.setAttribute('name', 'brand_active_'+nextBrand['ID']);
                                 inputTD.removeAttribute('checked');
                                 inputTD.setAttribute('id', 'brand_active_'+nextBrand['ID']);
                                 inputTD.checked = false;
                                 inputTD.nextElementSibling.setAttribute('for', 'brand_active_'+nextBrand['ID']);

                             }
                             if(key === 5)
                             {
                                 let inputTD = item.querySelector('input');
                                 inputTD.setAttribute('name', 'brand_popular_'+nextBrand['ID']);
                                 inputTD.setAttribute('id', 'brand_popular_'+nextBrand['ID']);
                                 inputTD.checked = false;
                                 inputTD.nextElementSibling.setAttribute('for', 'brand_popular_'+nextBrand['ID']);



                             }
                             if(key === 7)
                             {
                                 let inputTD = item.querySelector('input');
                                 inputTD.setAttribute('name', 'brand_sort_'+nextBrand['ID']);
                                 inputTD.value = 500;
                             }
                         }

                     });
                     brandTable.append(cloneTR);

                 },
                 onfailure: function () {
                     console.error(data);
                 }
             });
         }
     });
 });
</script>
